package com.example.eco_earn

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
