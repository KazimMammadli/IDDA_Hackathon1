class AppConfig {
  // API Base URL
  static const String baseUrl = 'https://pbscb6e1.rpcld.net/webhook';
  
  // API Endpoints
  static const String loginEndpoint = '/auth/login';
  static const String verifyOtpEndpoint = '/auth/verify-otp';
  static const String registerEndpoint = '/bea4f7c4-9d04-4738-95c7-ba89d4a9b051'; // Registration webhook
  static const String getUserEndpoint = '/user';
  static const String getTasksEndpoint = '/tasks/daily';
  static const String getUserTasksEndpoint = '/getUserTasks';
  static const String getTaskStatusEndpoint = '/tasks/status';
  static const String completeTaskEndpoint = '/tasks/complete';
  static const String updateUserEndpoint = '/user/update';
  static const String getUserTransactionsEndpoint = '/userTransactions';
  
  // App Info
  static const String appName = 'Eco Earn';
  
  // Default company ID
  static const String defaultCompanyId = 'comp_001';
}

