import 'dart:math';
import '../models/leaderboard_model.dart';
import '../models/spending_model.dart';
import '../models/task_model.dart';
import 'package:flutter/material.dart';

class MockDataService {
  static final Random _random = Random();

  // Generate 50 fake users for leaderboard
  static List<LeaderboardEntry> generateLeaderboard(String currentUserId) {
    final List<LeaderboardEntry> entries = [];
    final names = [
      'Alice Johnson', 'Bob Smith', 'Charlie Brown', 'Diana Prince',
      'Ethan Hunt', 'Fiona Green', 'George Wilson', 'Hannah Lee',
      'Ian Murphy', 'Julia Roberts', 'Kevin Hart', 'Laura Chen',
      'Mike Taylor', 'Nancy Drew', 'Oscar Martinez', 'Patty Holmes',
      'Quinn Adams', 'Rachel Green', 'Steve Jobs', 'Tina Turner',
      'Uma Thurman', 'Victor Hugo', 'Wendy Davis', 'Xavier Moon',
      'Yuki Tanaka', 'Zoe Williams', 'Adam Sandler', 'Bella Swan',
      'Chris Evans', 'Diana Ross', 'Emma Watson', 'Frank Miller',
      'Grace Kelly', 'Henry Ford', 'Iris West', 'Jack Black',
      'Kate Winslet', 'Liam Neeson', 'Maya Angelou', 'Neil Armstrong',
      'Olivia Pope', 'Paul Walker', 'Quincy Jones', 'Rose Byrne',
      'Sam Wilson', 'Tara Strong', 'Uma Thurman', 'Vincent Vega',
      'Will Smith', 'Yara Shahidi',
    ];

    for (int i = 0; i < 50; i++) {
      entries.add(LeaderboardEntry(
        userId: 'user_$i',
        name: names[i % names.length],
        score: _random.nextInt(1000) + 100,
        rank: i + 1,
      ));
    }

    // Sort by score descending
    entries.sort((a, b) => b.score.compareTo(a.score));
    
    // Update ranks
    for (int i = 0; i < entries.length; i++) {
      entries[i] = LeaderboardEntry(
        userId: entries[i].userId,
        name: entries[i].name,
        score: entries[i].score,
        rank: i + 1,
      );
    }

    return entries;
  }

  // Generate spending categories
  static List<SpendingCategory> getSpendingCategories() {
    return [
      SpendingCategory(
        name: 'Transport',
        amount: 450.0,
        co2Impact: 125.5,
        color: const Color(0xFFE63946), // Red
      ),
      SpendingCategory(
        name: 'Food',
        amount: 320.0,
        co2Impact: 85.2,
        color: const Color(0xFFFFB703), // Yellow
      ),
      SpendingCategory(
        name: 'Shopping',
        amount: 280.0,
        co2Impact: 62.3,
        color: const Color(0xFF52B788), // Green
      ),
      SpendingCategory(
        name: 'Energy',
        amount: 150.0,
        co2Impact: 45.8,
        color: const Color(0xFF2D6A4F), // Dark Green
      ),
    ];
  }

  // Generate daily tasks with descriptions
  static List<EcoTask> generateDailyTasks({String? userId}) {
    final defaultUserId = userId ?? 'mock_user';
    final now = DateTime.now();
    
    return [
      EcoTask(
        userId: defaultUserId,
        taskId: 'task_1',
        taskType: 'daily',
        taskName: 'Use public transport today',
        description:
            'Take public transportation instead of driving your car. This helps reduce carbon emissions significantly. Every trip counts!',
        category: 'Transport',
        points: 50,
        date: now,
        isActive: true,
        tips: [
          'Check your local transit app for routes',
          'Consider walking for short distances',
          'Combine errands in one trip',
        ],
      ),
      EcoTask(
        userId: defaultUserId,
        taskId: 'task_2',
        taskType: 'daily',
        taskName: 'Skip meat for lunch',
        description:
            'Choose a plant-based meal for lunch. Reducing meat consumption is one of the most effective ways to lower your carbon footprint.',
        category: 'Food',
        points: 30,
        date: now,
        isActive: true,
        tips: [
          'Try a vegetarian salad or wrap',
          'Explore plant-based protein options',
          'Many restaurants offer great meatless options',
        ],
      ),
      EcoTask(
        userId: defaultUserId,
        taskId: 'task_3',
        taskType: 'daily',
        taskName: 'Buy from sustainable brands',
        description:
            'Support companies that prioritize sustainability. Look for eco-friendly certifications and ethical production practices.',
        category: 'Shopping',
        points: 40,
        date: now,
        isActive: true,
        tips: [
          'Research brands before purchasing',
          'Look for sustainability certifications',
          'Support local and eco-friendly businesses',
        ],
      ),
      EcoTask(
        userId: defaultUserId,
        taskId: 'task_4',
        taskType: 'daily',
        taskName: 'Work from home',
        description:
            'If possible, work from home to eliminate commute emissions. This saves both time and reduces your carbon footprint.',
        category: 'Transport',
        points: 60,
        date: now,
        isActive: true,
        tips: [
          'Set up a comfortable workspace',
          'Stay productive with a routine',
          'Use video calls for collaboration',
        ],
      ),
      EcoTask(
        userId: defaultUserId,
        taskId: 'task_5',
        taskType: 'daily',
        taskName: 'Use reusable coffee cup',
        description:
            'Bring your own reusable cup instead of using disposable ones. Small changes make a big difference for the environment.',
        category: 'Lifestyle',
        points: 20,
        date: now,
        isActive: true,
        tips: [
          'Keep a reusable cup at work',
          'Many cafes offer discounts for bringing your own cup',
          'Consider a collapsible cup for convenience',
        ],
      ),
    ];
  }
}

