import 'package:dio/dio.dart';
import '../config/app_config.dart';

class ApiService {
  late Dio _dio;
  String? _authToken;
  String? _userId;

  ApiService() {
    _dio = Dio(BaseOptions(
      baseUrl: AppConfig.baseUrl,
      connectTimeout: const Duration(seconds: 30),
      receiveTimeout: const Duration(seconds: 30),
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
    ));

    _dio.interceptors.add(InterceptorsWrapper(
      onRequest: (options, handler) {
        if (_authToken != null) {
          options.headers['Authorization'] = 'Bearer $_authToken';
        }
        if (_userId != null) {
          options.headers['X-User-Id'] = _userId;
        }
        
        // Log all requests
        print('═══════════════════════════════════════════════════════════');
        print('🌐 API REQUEST');
        print('═══════════════════════════════════════════════════════════');
        print('📍 Method: ${options.method}');
        print('🔗 URL: ${options.baseUrl}${options.path}');
        print('📋 Headers: ${options.headers}');
        print('📦 Request Data: ${options.data}');
        print('🔍 Query Parameters: ${options.queryParameters}');
        print('═══════════════════════════════════════════════════════════');
        
        return handler.next(options);
      },
      onResponse: (response, handler) {
        // Log all responses
        print('═══════════════════════════════════════════════════════════');
        print('✅ API RESPONSE');
        print('═══════════════════════════════════════════════════════════');
        print('🔗 URL: ${response.requestOptions.baseUrl}${response.requestOptions.path}');
        print('📊 Status Code: ${response.statusCode}');
        print('📦 Response Data: ${response.data}');
        print('═══════════════════════════════════════════════════════════');
        
        return handler.next(response);
      },
      onError: (error, handler) {
        // Log all errors
        print('═══════════════════════════════════════════════════════════');
        print('❌ API ERROR');
        print('═══════════════════════════════════════════════════════════');
        print('🔗 URL: ${error.requestOptions.baseUrl}${error.requestOptions.path}');
        print('📍 Method: ${error.requestOptions.method}');
        print('📊 Status Code: ${error.response?.statusCode ?? 'N/A'}');
        print('❌ Error: ${error.message}');
        print('📦 Request Data: ${error.requestOptions.data}');
        if (error.response != null) {
          print('📦 Response Data: ${error.response?.data}');
        }
        print('═══════════════════════════════════════════════════════════');
        
        return handler.next(error);
      },
    ));
  }

  void setAuthToken(String token) {
    _authToken = token;
  }

  void setUserId(String userId) {
    _userId = userId;
  }

  void clearAuth() {
    _authToken = null;
    _userId = null;
  }

  // Auth Methods
  Future<Response> sendOtp(String phoneNumber) async {
    return await _dio.post(
      AppConfig.loginEndpoint,
      data: {'phone': phoneNumber},
    );
  }

  Future<Response> verifyOtp(String phoneNumber, String otp) async {
    return await _dio.post(
      AppConfig.verifyOtpEndpoint,
      data: {
        'phone': phoneNumber,
        'otp': otp,
      },
    );
  }

  Future<Response> registerUser({
    required String userId,
    required String phone,
    required String name,
    required String surname,
    String? email,
    String companyId = AppConfig.defaultCompanyId,
    bool bankConnected = false,
  }) async {
    // Generate email from name if not provided
    final generatedEmail = email ?? 
        '${name.toLowerCase()}.${surname.toLowerCase()}@example.com'.replaceAll(' ', '');
    
    final data = {
      'userId': userId,
      'phone': phone,
      'name': '$name $surname',
      'email': generatedEmail,
      'companyId': companyId,
      'bankConnected': bankConnected,
      'registeredAt': DateTime.now().toUtc().toIso8601String(),
      'avatar': 'https://example.com/avatars/$userId.jpg',
    };
    
    print('Sending registration to API: $data');
    
    return await _dio.post(
      AppConfig.registerEndpoint,
      data: data,
    );
  }

  Future<Response> updateBankConnection({
    required String userId,
    required String phone,
    required String name,
    String? email,
    String companyId = AppConfig.defaultCompanyId,
    required DateTime registeredAt,
    String? avatar,
  }) async {
    // Generate email from name if not provided (same format as registration)
    final nameParts = name.split(' ');
    String generatedEmail;
    if (nameParts.length >= 2) {
      final firstName = nameParts[0].toLowerCase();
      final lastName = nameParts[nameParts.length - 1].toLowerCase();
      generatedEmail = '$firstName.$lastName@example.com';
    } else {
      generatedEmail = email ?? '${name.toLowerCase().replaceAll(' ', '.')}@example.com';
    }
    
    final data = {
      'userId': userId,
      'phone': phone,
      'name': name,
      'email': email ?? generatedEmail,
      'companyId': companyId,
      'bankConnected': true, // Set to true for bank connection
      'registeredAt': registeredAt.toUtc().toIso8601String(),
      'avatar': avatar ?? 'https://example.com/avatars/$userId.jpg',
    };
    
    print('Sending bank connection update to API: $data');
    
    return await _dio.post(
      AppConfig.registerEndpoint, // Same endpoint
      data: data,
    );
  }

  // User Methods
  Future<Response> getUserInfo(String userId) async {
    return await _dio.get('${AppConfig.getUserEndpoint}/$userId');
  }

  Future<Response> updateUser(String userId, Map<String, dynamic> data) async {
    return await _dio.put(
      '${AppConfig.updateUserEndpoint}/$userId',
      data: data,
    );
  }

  // Tasks Methods
  Future<Response> getDailyTasks(String userId) async {
    return await _dio.get(
      AppConfig.getTasksEndpoint,
      queryParameters: {'userId': userId},
    );
  }

  Future<Response> getUserTasks(String userId) async {
    // Ensure userId is set in the service for header injection
    _userId = userId;
    
    return await _dio.get(
      AppConfig.getUserTasksEndpoint,
      queryParameters: {'userId': userId},
    );
  }

  Future<Response> getTaskStatus(String userId, String taskId) async {
    return await _dio.get(
      '${AppConfig.getTaskStatusEndpoint}/$taskId',
      queryParameters: {'userId': userId},
    );
  }

  Future<Response> completeTask(String userId, String taskId) async {
    return await _dio.post(
      '${AppConfig.completeTaskEndpoint}/$taskId',
      data: {'userId': userId},
    );
  }

  // Transactions Methods
  Future<Response> getUserTransactions(String userId) async {
    // Ensure userId is set in the service for header injection
    _userId = userId;
    
    return await _dio.get(
      AppConfig.getUserTransactionsEndpoint,
      queryParameters: {'userId': userId},
    );
  }
}

