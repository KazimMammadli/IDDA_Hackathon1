import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/user_model.dart';
import '../models/task_model.dart';

class StorageService {
  static const String _userKey = 'current_user';
  static const String _userIdKey = 'user_id';
  static const String _tasksKey = 'daily_tasks';
  static const String _monthlyScoreKey = 'monthly_score';
  static const String _monthlyBonusKey = 'monthly_bonus';
  
  // User ID methods (for quick access)
  Future<void> saveUserId(String userId) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_userIdKey, userId);
  }

  Future<String?> getUserId() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_userIdKey);
  }

  Future<void> clearUserId() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_userIdKey);
  }

  // User methods
  Future<void> saveUser(User user) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_userKey, jsonEncode(user.toJson()));
  }

  Future<User?> getUser() async {
    final prefs = await SharedPreferences.getInstance();
    final userJson = prefs.getString(_userKey);
    if (userJson != null) {
      return User.fromJson(jsonDecode(userJson));
    }
    return null;
  }

  Future<void> clearUser() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_userKey);
    await prefs.remove(_userIdKey);
  }

  // Tasks methods
  Future<void> saveTasks(List<EcoTask> tasks) async {
    final prefs = await SharedPreferences.getInstance();
    final tasksJson = tasks.map((t) => t.toJson()).toList();
    await prefs.setString(_tasksKey, jsonEncode(tasksJson));
  }

  Future<List<EcoTask>> getTasks() async {
    final prefs = await SharedPreferences.getInstance();
    final tasksJson = prefs.getString(_tasksKey);
    if (tasksJson != null) {
      final List<dynamic> decoded = jsonDecode(tasksJson);
      return decoded.map((json) => EcoTask.fromJson(json)).toList();
    }
    return [];
  }

  // Monthly score methods
  Future<void> saveMonthlyScore(int score) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_monthlyScoreKey, score);
  }

  Future<int> getMonthlyScore() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getInt(_monthlyScoreKey) ?? 0;
  }

  // Monthly bonus methods
  Future<void> saveMonthlyBonus(double bonus) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble(_monthlyBonusKey, bonus);
  }

  Future<double> getMonthlyBonus() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getDouble(_monthlyBonusKey) ?? 0.0;
  }
}

