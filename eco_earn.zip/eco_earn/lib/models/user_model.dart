class User {
  final String id;
  final String? phone;
  final String? email;
  final String name;
  final String? surname;
  final int totalLifetimePoints;
  final double totalBonusesThisYear;
  final bool hasOnboarded;
  final bool hasBankConnected;
  final String? authToken;
  final DateTime? createdAt;
  final Map<String, dynamic>? metadata;

  User({
    required this.id,
    this.phone,
    this.email,
    required this.name,
    this.surname,
    this.totalLifetimePoints = 0,
    this.totalBonusesThisYear = 0.0,
    this.hasOnboarded = false,
    this.hasBankConnected = false,
    this.authToken,
    this.createdAt,
    this.metadata,
  });

  String get fullName => surname != null ? '$name $surname' : name;

  User copyWith({
    String? id,
    String? phone,
    String? email,
    String? name,
    String? surname,
    int? totalLifetimePoints,
    double? totalBonusesThisYear,
    bool? hasOnboarded,
    bool? hasBankConnected,
    String? authToken,
    DateTime? createdAt,
    Map<String, dynamic>? metadata,
  }) {
    return User(
      id: id ?? this.id,
      phone: phone ?? this.phone,
      email: email ?? this.email,
      name: name ?? this.name,
      surname: surname ?? this.surname,
      totalLifetimePoints: totalLifetimePoints ?? this.totalLifetimePoints,
      totalBonusesThisYear: totalBonusesThisYear ?? this.totalBonusesThisYear,
      hasOnboarded: hasOnboarded ?? this.hasOnboarded,
      hasBankConnected: hasBankConnected ?? this.hasBankConnected,
      authToken: authToken ?? this.authToken,
      createdAt: createdAt ?? this.createdAt,
      metadata: metadata ?? this.metadata,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'phone': phone,
      'email': email,
      'name': name,
      'surname': surname,
      'totalLifetimePoints': totalLifetimePoints,
      'totalBonusesThisYear': totalBonusesThisYear,
      'hasOnboarded': hasOnboarded,
      'hasBankConnected': hasBankConnected,
      'authToken': authToken,
      'createdAt': createdAt?.toIso8601String(),
      'metadata': metadata,
    };
  }

  factory User.fromJson(Map<String, dynamic> json) {
    // Helper to parse boolean - handles both 'bankConnected' and 'hasBankConnected'
    bool parseBool(dynamic value) {
      if (value == null) return false;
      if (value is bool) return value;
      if (value is String) {
        return value.toLowerCase() == 'true' || value == '1';
      }
      if (value is int) return value != 0;
      return false;
    }

    // Parse bank connection status - API may use 'bankConnected' or 'hasBankConnected'
    final bankConnected = parseBool(json['bankConnected'] ?? json['hasBankConnected']);

    return User(
      id: json['id']?.toString() ?? json['userId']?.toString() ?? '',
      phone: json['phone'],
      email: json['email'],
      name: json['name'] ?? '',
      surname: json['surname'],
      totalLifetimePoints: json['totalLifetimePoints'] ?? 0,
      totalBonusesThisYear: (json['totalBonusesThisYear'] ?? 0.0).toDouble(),
      hasOnboarded: parseBool(json['hasOnboarded']),
      hasBankConnected: bankConnected,
      authToken: json['authToken'],
      createdAt: json['createdAt'] != null
          ? DateTime.parse(json['createdAt'])
          : (json['registeredAt'] != null ? DateTime.parse(json['registeredAt']) : null),
      metadata: json['metadata'] as Map<String, dynamic>?,
    );
  }
}

