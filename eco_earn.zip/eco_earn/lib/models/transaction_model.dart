class Transaction {
  final int? rowNumber;
  final String? userId;
  final String date;
  final double? debit;
  final double? kredit;
  final double balance;
  final String description;
  final String last4;

  Transaction({
    this.rowNumber,
    this.userId,
    required this.date,
    this.debit,
    this.kredit,
    required this.balance,
    required this.description,
    required this.last4,
  });

  factory Transaction.fromJson(Map<String, dynamic> json) {
    // Helper function to parse numeric values that might come as strings or numbers
    double? parseDouble(dynamic value) {
      if (value == null) return null;
      if (value is num) return value.toDouble();
      if (value is String) {
        final parsed = double.tryParse(value);
        return parsed;
      }
      return null;
    }

    double parseDoubleRequired(dynamic value) {
      if (value == null) return 0.0;
      if (value is num) return value.toDouble();
      if (value is String) {
        final parsed = double.tryParse(value);
        return parsed ?? 0.0;
      }
      return 0.0;
    }

    return Transaction(
      rowNumber: json['row_number'] != null
          ? (json['row_number'] is int
              ? json['row_number']
              : int.tryParse(json['row_number'].toString()))
          : null,
      userId: json['userId']?.toString(),
      date: json['date']?.toString() ?? '',
      debit: parseDouble(json['debit']),
      kredit: parseDouble(json['kredit']),
      balance: parseDoubleRequired(json['balance']),
      description: json['description']?.toString() ?? '',
      last4: json['last4']?.toString() ?? '',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'row_number': rowNumber,
      'userId': userId,
      'date': date,
      'debit': debit,
      'kredit': kredit,
      'balance': balance,
      'description': description,
      'last4': last4,
    };
  }

  bool get isDebit => debit != null && debit! > 0;
  bool get isCredit => kredit != null && kredit! > 0;
  double get amount => debit ?? kredit ?? 0.0;
}

