class LeaderboardEntry {
  final String userId;
  final String name;
  final int score;
  final int rank;

  LeaderboardEntry({
    required this.userId,
    required this.name,
    required this.score,
    required this.rank,
  });
}

