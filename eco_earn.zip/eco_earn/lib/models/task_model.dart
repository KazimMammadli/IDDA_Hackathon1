class EcoTask {
  final String userId;
  final String taskId;
  final String taskType;
  final int points;
  final DateTime? completedAt;
  final DateTime? date;
  final bool isActive;
  final bool isVerified;
  final String? category;
  final String taskName;
  
  // Legacy fields for backward compatibility
  final String? description;
  final String? iconUrl;
  final List<String>? tips;
  final DateTime? startDate;
  final DateTime? endDate;
  final double? progress;
  final Map<String, dynamic>? metadata;

  EcoTask({
    required this.userId,
    required this.taskId,
    required this.taskType,
    required this.points,
    this.completedAt,
    this.date,
    this.isActive = true,
    this.isVerified = false,
    this.category,
    required this.taskName,
    this.description,
    this.iconUrl,
    this.tips,
    this.startDate,
    this.endDate,
    this.progress,
    this.metadata,
  });

  // Computed properties
  String get id => taskId;
  String get title => taskName;
  // Task is completed if isVerified is true
  bool get isCompleted => isVerified;

  EcoTask copyWith({
    String? userId,
    String? taskId,
    String? taskType,
    int? points,
    DateTime? completedAt,
    DateTime? date,
    bool? isActive,
    bool? isVerified,
    String? category,
    String? taskName,
    String? description,
    String? iconUrl,
    List<String>? tips,
    DateTime? startDate,
    DateTime? endDate,
    double? progress,
    Map<String, dynamic>? metadata,
  }) {
    return EcoTask(
      userId: userId ?? this.userId,
      taskId: taskId ?? this.taskId,
      taskType: taskType ?? this.taskType,
      points: points ?? this.points,
      completedAt: completedAt ?? this.completedAt,
      date: date ?? this.date,
      isActive: isActive ?? this.isActive,
      isVerified: isVerified ?? this.isVerified,
      category: category ?? this.category,
      taskName: taskName ?? this.taskName,
      description: description ?? this.description,
      iconUrl: iconUrl ?? this.iconUrl,
      tips: tips ?? this.tips,
      startDate: startDate ?? this.startDate,
      endDate: endDate ?? this.endDate,
      progress: progress ?? this.progress,
      metadata: metadata ?? this.metadata,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'userId': userId,
      'taskId': taskId,
      'taskType': taskType,
      'points': points,
      'completedAt': completedAt?.toIso8601String(),
      'date': date?.toIso8601String(),
      'isActive': isActive,
      'isVerified': isVerified,
      'category': category,
      'taskName': taskName,
      'description': description,
      'iconUrl': iconUrl,
      'tips': tips,
      'startDate': startDate?.toIso8601String(),
      'endDate': endDate?.toIso8601String(),
      'progress': progress,
      'metadata': metadata,
    };
  }

  factory EcoTask.fromJson(Map<String, dynamic> json) {
    // Helper to parse date/time from various formats
    DateTime? parseDateTime(dynamic value) {
      if (value == null) return null;
      if (value is DateTime) return value;
      if (value is String) {
        try {
          return DateTime.parse(value);
        } catch (e) {
          print('Error parsing date: $value, error: $e');
          return null;
        }
      }
      return null;
    }

    // Helper to parse boolean
    bool parseBool(dynamic value) {
      if (value == null) return true;
      if (value is bool) return value;
      if (value is String) {
        return value.toLowerCase() == 'true' || value == '1';
      }
      if (value is int) return value != 0;
      return true;
    }

    // Helper to parse int
    int parseInt(dynamic value) {
      if (value == null) return 0;
      if (value is int) return value;
      if (value is String) return int.tryParse(value) ?? 0;
      if (value is double) return value.toInt();
      return 0;
    }

    return EcoTask(
      userId: json['userId']?.toString() ?? '',
      taskId: json['taskId']?.toString() ?? json['id']?.toString() ?? '',
      taskType: json['taskType']?.toString() ?? '',
      points: parseInt(json['points']),
      completedAt: parseDateTime(json['completedAt']),
      date: parseDateTime(json['date']),
      isActive: parseBool(json['isActive']),
      // isVerified defaults to false if not provided or null
      isVerified: json['isVerified'] != null ? parseBool(json['isVerified']) : false,
      category: json['category']?.toString(),
      taskName: json['taskName']?.toString() ?? json['title']?.toString() ?? '',
      // Legacy fields for backward compatibility
      description: json['description']?.toString(),
      iconUrl: json['iconUrl']?.toString(),
      tips: json['tips'] != null ? List<String>.from(json['tips']) : null,
      startDate: parseDateTime(json['startDate']),
      endDate: parseDateTime(json['endDate']),
      progress: json['progress']?.toDouble(),
      metadata: json['metadata'] as Map<String, dynamic>?,
    );
  }
}

