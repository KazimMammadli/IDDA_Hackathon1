import 'package:flutter/material.dart';

class SpendingCategory {
  final String name;
  final double amount;
  final double co2Impact;
  final Color color;

  SpendingCategory({
    required this.name,
    required this.amount,
    required this.co2Impact,
    required this.color,
  });
}

