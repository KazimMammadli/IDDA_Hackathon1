import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:fl_chart/fl_chart.dart';
import '../../providers/spending_provider.dart';
import '../../theme/app_theme.dart';
import '../../models/spending_model.dart';

class InsightsScreen extends ConsumerStatefulWidget {
  const InsightsScreen({super.key});

  @override
  ConsumerState<InsightsScreen> createState() => _InsightsScreenState();
}

class _InsightsScreenState extends ConsumerState<InsightsScreen> {
  int touchedIndex = -1;
  int touchedBarGroupIndex = -1;
  int showingTooltipIndex = -1;

  @override
  Widget build(BuildContext context) {
    final categories = ref.watch(spendingCategoriesProvider);

    return Scaffold(
      backgroundColor: AppTheme.lightGray,
      appBar: AppBar(
        title: const Text(
          'Spending Insights',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 22,
          ),
        ),
        elevation: 0,
        backgroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // CO2 Impact by Category Card - Light Green Background
            Container(
              margin: const EdgeInsets.all(16),
              padding: const EdgeInsets.all(24.0),
              decoration: BoxDecoration(
                color: AppTheme.lightGreen.withOpacity(0.1),
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 10,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'CO2 Impact Distribution (Pie)',
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                          fontWeight: FontWeight.bold,
                          color: AppTheme.primaryGreen,
                          fontSize: 20,
                        ),
                  ),
                  const SizedBox(height: 24),
                  LayoutBuilder(
                    builder: (context, constraints) {
                      final screenWidth = constraints.maxWidth;
                      final isSmallScreen = screenWidth < 350;
                      // Make chart smaller to prevent overflow
                      final chartSize = isSmallScreen ? 180.0 : 220.0;
                      final centerRadius = isSmallScreen ? 50.0 : 65.0;
                      
                      return Column(
                        children: [
                          // Add top padding for chart
                          const SizedBox(height: 44),
                          // Chart - centered
                          Center(
                            child: SizedBox(
                              height: chartSize,
                              width: chartSize,
                              child: PieChart(
                                PieChartData(
                                  sectionsSpace: 3,
                                  centerSpaceRadius: centerRadius,
                                  sections: _buildPieChartSections(categories),
                                  pieTouchData: PieTouchData(
                                    touchCallback: (FlTouchEvent event, pieTouchResponse) {
                                      setState(() {
                                        if (!event.isInterestedForInteractions ||
                                            pieTouchResponse == null ||
                                            pieTouchResponse.touchedSection == null) {
                                          touchedIndex = -1;
                                          return;
                                        }
                                        touchedIndex = pieTouchResponse.touchedSection!.touchedSectionIndex;
                                      });
                                    },
                                    enabled: true,
                                  ),
                                  startDegreeOffset: -90,
                                  borderData: FlBorderData(show: false),
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 64),
                          // Legend - below chart with increased height
                          SizedBox(
                            height: isSmallScreen ? 280 : 300,
                            child: ListView(
                              shrinkWrap: true,
                              physics: const NeverScrollableScrollPhysics(),
                              children: categories.asMap().entries.map((entry) {
                                final index = entry.key;
                                final category = entry.value;
                                final total = categories.fold<double>(
                                  0,
                                  (sum, cat) => sum + cat.co2Impact,
                                );
                                final percentage = (category.co2Impact / total) * 100;
                                final isTouched = touchedIndex == index;
                                
                                return GestureDetector(
                                  onTap: () {
                                    setState(() {
                                      touchedIndex = touchedIndex == index ? -1 : index;
                                    });
                                  },
                                  child: AnimatedContainer(
                                    duration: const Duration(milliseconds: 200),
                                    curve: Curves.easeInOut,
                                    padding: EdgeInsets.all(isSmallScreen ? 10 : 12),
                                    margin: const EdgeInsets.only(bottom: 8),
                                    decoration: BoxDecoration(
                                      color: isTouched
                                          ? category.color.withOpacity(0.1)
                                          : Colors.transparent,
                                      borderRadius: BorderRadius.circular(12),
                                      border: isTouched
                                          ? Border.all(
                                              color: category.color.withOpacity(0.5),
                                              width: 2,
                                            )
                                          : null,
                                    ),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Container(
                                          width: isTouched ? 18 : 14,
                                          height: isTouched ? 18 : 14,
                                          decoration: BoxDecoration(
                                            color: category.color,
                                            shape: BoxShape.circle,
                                            boxShadow: isTouched
                                                ? [
                                                    BoxShadow(
                                                      color: category.color.withOpacity(0.5),
                                                      blurRadius: 8,
                                                      offset: const Offset(0, 2),
                                                    ),
                                                  ]
                                                : null,
                                          ),
                                        ),
                                        SizedBox(width: isSmallScreen ? 10 : 12),
                                        Flexible(
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            mainAxisSize: MainAxisSize.min,
                                            children: [
                                              Text(
                                                category.name,
                                                style: Theme.of(context)
                                                    .textTheme
                                                    .bodyMedium
                                                    ?.copyWith(
                                                      fontWeight: isTouched
                                                          ? FontWeight.bold
                                                          : FontWeight.w600,
                                                      fontSize: isTouched 
                                                          ? (isSmallScreen ? 14 : 15) 
                                                          : (isSmallScreen ? 13 : 14),
                                                      color: isTouched
                                                          ? category.color
                                                          : Colors.black87,
                                                    ),
                                              ),
                                              const SizedBox(height: 2),
                                              Text(
                                                '${percentage.toStringAsFixed(1)}%',
                                                style: Theme.of(context)
                                                    .textTheme
                                                    .bodySmall
                                                    ?.copyWith(
                                                      color: isTouched
                                                          ? category.color
                                                          : AppTheme.darkGray,
                                                      fontSize: isSmallScreen ? 12 : 13,
                                                      fontWeight: isTouched
                                                          ? FontWeight.bold
                                                          : FontWeight.normal,
                                                    ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                );
                              }).toList(),
                            ),
                          ),
                        ],
                      );
                    },
                  ),
                ],
              ),
            ),
            // Bar Chart - CO2 Impact Comparison
            _buildBarChartCard(categories),
            
            // Line Chart - Spending Trend
            _buildLineChartCard(categories),
            
            // Category Breakdown Section
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 16),
              child: Text(
                'Category Breakdown',
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.bold,
                      color: AppTheme.primaryGreen,
                      fontSize: 20,
                    ),
              ),
            ),
            ...categories.map((category) => _CategoryCard(category: category)),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }

  List<PieChartSectionData> _buildPieChartSections(
      List<SpendingCategory> categories) {
    final total = categories.fold<double>(
      0,
      (sum, category) => sum + category.co2Impact,
    );

    return categories.asMap().entries.map((entry) {
      final index = entry.key;
      final category = entry.value;
      final percentage = (category.co2Impact / total) * 100;
      final isTouched = index == touchedIndex;
      // Reduced radius to match smaller chart size
      final radius = isTouched ? 100.0 : 90.0;
      
      return PieChartSectionData(
        value: category.co2Impact,
        title: percentage > 5 ? '${percentage.toStringAsFixed(1)}%' : '',
        color: category.color,
        radius: radius,
        titleStyle: TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.bold,
          color: Colors.white,
          shadows: [
            Shadow(
              color: Colors.black.withOpacity(0.4),
              blurRadius: 4,
              offset: const Offset(0, 1),
            ),
          ],
        ),
        badgeWidget: percentage <= 5
            ? Container(
                padding: const EdgeInsets.all(5),
                decoration: BoxDecoration(
                  color: category.color,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.2),
                      blurRadius: 3,
                      offset: const Offset(0, 1),
                    ),
                  ],
                ),
                child: Text(
                  '${percentage.toStringAsFixed(1)}%',
                  style: const TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              )
            : null,
        badgePositionPercentageOffset: 1.25,
      );
    }).toList();
  }

  Widget _buildBarChartCard(List<SpendingCategory> categories) {
    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.all(24.0),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'CO2 Impact Comparison (Bar)',
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.bold,
                  color: AppTheme.primaryGreen,
                  fontSize: 20,
                ),
          ),
          const SizedBox(height: 24),
          SizedBox(
            height: 300,
            child: BarChart(
              BarChartData(
                alignment: BarChartAlignment.spaceAround,
                maxY: categories.map((c) => c.co2Impact).reduce((a, b) => a > b ? a : b) * 1.2,
                barTouchData: BarTouchData(
                  enabled: true,
                  touchTooltipData: BarTouchTooltipData(
                    getTooltipColor: (touchedSpot) => AppTheme.primaryGreen,
                    getTooltipItem: (group, groupIndex, rod, rodIndex) {
                      final category = categories[groupIndex];
                      return BarTooltipItem(
                        '${category.name}\n${category.co2Impact.toStringAsFixed(1)} kg CO₂',
                        const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                      );
                    },
                  ),
                  touchCallback: (FlTouchEvent event, barTouchResponse) {
                    setState(() {
                      if (!event.isInterestedForInteractions ||
                          barTouchResponse == null ||
                          barTouchResponse.spot == null) {
                        touchedBarGroupIndex = -1;
                        showingTooltipIndex = -1;
                        return;
                      }
                      touchedBarGroupIndex = barTouchResponse.spot!.touchedBarGroupIndex;
                      showingTooltipIndex = barTouchResponse.spot!.touchedRodDataIndex;
                    });
                  },
                ),
                titlesData: FlTitlesData(
                  show: true,
                  rightTitles: const AxisTitles(
                    sideTitles: SideTitles(showTitles: false),
                  ),
                  topTitles: const AxisTitles(
                    sideTitles: SideTitles(showTitles: false),
                  ),
                  bottomTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      getTitlesWidget: (double value, TitleMeta meta) {
                        if (value.toInt() >= 0 && value.toInt() < categories.length) {
                          return Padding(
                            padding: const EdgeInsets.only(top: 8.0),
                            child: Text(
                              categories[value.toInt()].name,
                              style: TextStyle(
                                color: AppTheme.darkGray,
                                fontWeight: FontWeight.w600,
                                fontSize: 12,
                              ),
                            ),
                          );
                        }
                        return const Text('');
                      },
                      reservedSize: 40,
                    ),
                  ),
                  leftTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      reservedSize: 45,
                      getTitlesWidget: (double value, TitleMeta meta) {
                        return Text(
                          '${value.toInt()}',
                          style: TextStyle(
                            color: AppTheme.darkGray,
                            fontWeight: FontWeight.w500,
                            fontSize: 12,
                          ),
                        );
                      },
                    ),
                  ),
                ),
                borderData: FlBorderData(
                  show: true,
                  border: Border(
                    bottom: BorderSide(color: AppTheme.mediumGray, width: 1),
                    left: BorderSide(color: AppTheme.mediumGray, width: 1),
                  ),
                ),
                barGroups: categories.asMap().entries.map((entry) {
                  final index = entry.key;
                  final category = entry.value;
                  
                  return BarChartGroupData(
                    x: index,
                    barRods: [
                      BarChartRodData(
                        toY: category.co2Impact,
                        color: category.color,
                        width: 32,
                        borderRadius: const BorderRadius.vertical(
                          top: Radius.circular(8),
                        ),
                        backDrawRodData: BackgroundBarChartRodData(
                          show: true,
                          toY: categories
                                  .map((c) => c.co2Impact)
                                  .reduce((a, b) => a > b ? a : b) *
                              1.2,
                          color: AppTheme.mediumGray.withOpacity(0.1),
                        ),
                      ),
                    ],
                  );
                }).toList(),
                gridData: FlGridData(
                  show: true,
                  drawVerticalLine: false,
                  horizontalInterval: 20,
                  getDrawingHorizontalLine: (value) {
                    return FlLine(
                      color: AppTheme.mediumGray.withOpacity(0.2),
                      strokeWidth: 1,
                    );
                  },
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLineChartCard(List<SpendingCategory> categories) {
    // Create mock data for spending trends over months
    final months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'];
    final spendingTrends = List.generate(
      months.length,
      (index) => categories.fold<double>(
        0,
        (sum, category) => sum + (category.amount * (0.8 + (index * 0.04))),
      ),
    );
    final co2Trends = List.generate(
      months.length,
      (index) => categories.fold<double>(
        0,
        (sum, category) => sum + (category.co2Impact * (0.8 + (index * 0.04))),
      ),
    );

    final maxSpending = spendingTrends.reduce((a, b) => a > b ? a : b);
    final maxCo2 = co2Trends.reduce((a, b) => a > b ? a : b);

    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.all(24.0),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Spending & CO2 Trends',
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.bold,
                  color: AppTheme.primaryGreen,
                  fontSize: 20,
                ),
          ),
          const SizedBox(height: 24),
          SizedBox(
            height: 280,
            child: LineChart(
              LineChartData(
                gridData: FlGridData(
                  show: true,
                  drawVerticalLine: false,
                  horizontalInterval: 200,
                  getDrawingHorizontalLine: (value) {
                    return FlLine(
                      color: AppTheme.mediumGray.withOpacity(0.2),
                      strokeWidth: 1,
                    );
                  },
                ),
                titlesData: FlTitlesData(
                  show: true,
                  rightTitles: const AxisTitles(
                    sideTitles: SideTitles(showTitles: false),
                  ),
                  topTitles: const AxisTitles(
                    sideTitles: SideTitles(showTitles: false),
                  ),
                  bottomTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      reservedSize: 30,
                      getTitlesWidget: (double value, TitleMeta meta) {
                        if (value.toInt() >= 0 && value.toInt() < months.length) {
                          return Text(
                            months[value.toInt()],
                            style: TextStyle(
                              color: AppTheme.darkGray,
                              fontWeight: FontWeight.w600,
                              fontSize: 12,
                            ),
                          );
                        }
                        return const Text('');
                      },
                    ),
                  ),
                  leftTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      reservedSize: 50,
                      getTitlesWidget: (double value, TitleMeta meta) {
                        return Text(
                          '€${value.toInt()}',
                          style: TextStyle(
                            color: AppTheme.darkGray,
                            fontWeight: FontWeight.w500,
                            fontSize: 11,
                          ),
                        );
                      },
                    ),
                  ),
                ),
                borderData: FlBorderData(
                  show: true,
                  border: Border.all(color: AppTheme.mediumGray, width: 1),
                ),
                minX: 0,
                maxX: months.length - 1.toDouble(),
                minY: 0,
                maxY: maxSpending * 1.1,
                lineBarsData: [
                  // Spending Line
                  LineChartBarData(
                    spots: spendingTrends.asMap().entries.map((entry) {
                      return FlSpot(entry.key.toDouble(), entry.value);
                    }).toList(),
                    isCurved: true,
                    color: AppTheme.primaryGreen,
                    barWidth: 4,
                    isStrokeCapRound: true,
                    dotData: const FlDotData(show: true),
                    belowBarData: BarAreaData(
                      show: true,
                      color: AppTheme.primaryGreen.withOpacity(0.1),
                    ),
                  ),
                  // CO2 Impact Line (right Y axis)
                  LineChartBarData(
                    spots: co2Trends.asMap().entries.map((entry) {
                      // Scale CO2 to spending range for visualization
                      final scaledValue = (entry.value / maxCo2) * maxSpending;
                      return FlSpot(entry.key.toDouble(), scaledValue);
                    }).toList(),
                    isCurved: true,
                    color: const Color(0xFFE63946),
                    barWidth: 4,
                    isStrokeCapRound: true,
                    dotData: const FlDotData(show: true),
                    dashArray: [5, 5],
                  ),
                ],
                lineTouchData: LineTouchData(
                  enabled: true,
                  touchTooltipData: LineTouchTooltipData(
                    getTooltipItems: (List<LineBarSpot> touchedBarSpots) {
                      return touchedBarSpots.map((barSpot) {
                        final monthIndex = barSpot.x.toInt();
                        if (barSpot.barIndex == 0) {
                          // Spending
                          return LineTooltipItem(
                            '${months[monthIndex]}\n€${barSpot.y.toStringAsFixed(2)}',
                            const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 14,
                            ),
                          );
                        } else {
                          // CO2 - convert back from scaled value
                          final actualCo2 = (barSpot.y / maxSpending) * maxCo2;
                          return LineTooltipItem(
                            '${months[monthIndex]}\n${actualCo2.toStringAsFixed(1)} kg CO₂',
                            const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 14,
                            ),
                          );
                        }
                      }).toList();
                    },
                    getTooltipColor: (touchedSpot) => AppTheme.primaryGreen,
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _buildLegendItem(AppTheme.primaryGreen, 'Spending'),
              const SizedBox(width: 24),
              _buildLegendItem(const Color(0xFFE63946), 'CO2 Impact'),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildLegendItem(Color color, String label) {
    return Row(
      children: [
        Container(
          width: 16,
          height: 16,
          decoration: BoxDecoration(
            color: color,
            shape: BoxShape.circle,
          ),
        ),
        const SizedBox(width: 8),
        Text(
          label,
          style: TextStyle(
            color: AppTheme.darkGray,
            fontWeight: FontWeight.w600,
            fontSize: 13,
          ),
        ),
      ],
    );
  }
}

class _CategoryCard extends StatelessWidget {
  final SpendingCategory category;

  const _CategoryCard({required this.category});

  Color _getSustainabilityColor(double co2Impact) {
    if (co2Impact < 60) {
      return AppTheme.lightGreen; // Green - good
    } else if (co2Impact < 100) {
      return const Color(0xFFFFB703); // Orange - moderate
    } else {
      return const Color(0xFFE63946); // Red - high
    }
  }

  String _getSustainabilityLabel(double co2Impact) {
    if (co2Impact < 60) {
      return 'Low Impact';
    } else if (co2Impact < 100) {
      return 'Moderate Impact';
    } else {
      return 'High Impact';
    }
  }

  @override
  Widget build(BuildContext context) {
    final sustainabilityColor = _getSustainabilityColor(category.co2Impact);
    final sustainabilityLabel = _getSustainabilityLabel(category.co2Impact);

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Row(
          children: [
            // Color indicator - larger and more prominent
            Container(
              width: 20,
              height: 20,
              decoration: BoxDecoration(
                color: category.color,
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: category.color.withOpacity(0.3),
                    blurRadius: 4,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 16),
            // Category info
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    category.name,
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                          fontSize: 17,
                          color: Colors.black87,
                        ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    '€${category.amount.toStringAsFixed(2)}',
                    style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                          color: AppTheme.darkGray,
                          fontSize: 15,
                          fontWeight: FontWeight.w500,
                        ),
                  ),
                ],
              ),
            ),
            // CO2 impact badge
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 14,
                    vertical: 8,
                  ),
                  decoration: BoxDecoration(
                    color: sustainabilityColor.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: sustainabilityColor.withOpacity(0.3),
                      width: 1,
                    ),
                  ),
                  child: Text(
                    '${category.co2Impact.toStringAsFixed(1)} kg CO₂',
                    style: TextStyle(
                      color: sustainabilityColor,
                      fontWeight: FontWeight.bold,
                      fontSize: 13,
                    ),
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  sustainabilityLabel,
                  style: TextStyle(
                    color: sustainabilityColor,
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

