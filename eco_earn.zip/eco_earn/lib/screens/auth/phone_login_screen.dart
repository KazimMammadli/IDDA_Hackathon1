import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:pin_code_fields/pin_code_fields.dart';
import '../../providers/auth_provider.dart';
import '../../theme/app_theme.dart';
import '../../widgets/custom_button.dart';
import '../../widgets/loading_overlay.dart';
import '../registration/registration_screen.dart';
import '../main/main_screen.dart';

class PhoneLoginScreen extends ConsumerStatefulWidget {
  const PhoneLoginScreen({super.key});

  @override
  ConsumerState<PhoneLoginScreen> createState() => _PhoneLoginScreenState();
}

class _PhoneLoginScreenState extends ConsumerState<PhoneLoginScreen> {
  final _formKey = GlobalKey<FormState>();
  final _phoneController = TextEditingController();
  final _otpController = TextEditingController();
  
  bool _isOtpSent = false;
  bool _isLoading = false;
  int _countdown = 60;
  bool _canResend = false;
  String _phoneNumber = ''; // Store phone number separately to avoid controller access after disposal

  @override
  void dispose() {
    _phoneController.dispose();
    _otpController.dispose();
    super.dispose();
  }

  Future<void> _sendOtp() async {
    if (!_formKey.currentState!.validate()) return;

    final phoneNumber = _phoneController.text.trim();
    
    setState(() {
      _isLoading = true;
      _isOtpSent = true;
      _canResend = false;
      _countdown = 60;
      _phoneNumber = phoneNumber; // Store phone number before async operation
    });

    try {
      final success = await ref
          .read(authProvider.notifier)
          .sendOtp(phoneNumber);

      if (!mounted) return;

      if (success) {
        _startCountdown();
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('OTP sent to your phone number'),
            backgroundColor: AppTheme.primaryGreen,
          ),
        );
      } else {
        setState(() => _isOtpSent = false);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Failed to send OTP. Please try again.'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } catch (e) {
      if (!mounted) return;
      setState(() => _isOtpSent = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: ${e.toString()}')),
      );
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  Future<void> _verifyOtp() async {
    final otp = _otpController.text.trim();
    
    if (otp.length != 6) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please enter a valid 6-digit OTP'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    final phoneNumber = _phoneNumber.isNotEmpty 
        ? _phoneNumber 
        : _phoneController.text.trim();

    setState(() => _isLoading = true);

    try {
      final result = await ref
          .read(authProvider.notifier)
          .verifyOtp(phoneNumber, otp);

      if (!mounted) return;

      if (result != null) {
        // Check if user needs to register
        if (result['needsRegistration'] == true) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (_) => RegistrationScreen(
                phoneNumber: phoneNumber,
                authToken: result['authToken'],
              ),
            ),
          );
        } else {
          // User exists, navigate to main app
          final user = ref.read(authProvider);
          if (user != null && user.hasOnboarded) {
            Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(builder: (_) => const MainScreen()),
              (route) => false,
            );
          } else {
            // Navigate to onboarding or registration
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (_) => RegistrationScreen(
                  phoneNumber: phoneNumber,
                  authToken: result['authToken'],
                ),
              ),
            );
          }
        }
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Invalid OTP. Please try again. ${e.toString()}'),
          backgroundColor: Colors.red,
        ),
      );
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  void _startCountdown() {
    Future.delayed(const Duration(seconds: 1), () {
      if (mounted && _countdown > 0) {
        setState(() {
          _countdown--;
        });
        _startCountdown();
      } else if (mounted) {
        setState(() {
          _canResend = true;
        });
      }
    });
  }

  void _resendOtp() {
    setState(() {
      _isOtpSent = false;
      _otpController.clear();
      _canResend = false;
    });
    _sendOtp();
  }

  @override
  Widget build(BuildContext context) {
    return LoadingOverlay(
      isLoading: _isLoading,
      child: Scaffold(
        body: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24.0),
            child: Form(
              key: _formKey,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const SizedBox(height: 60),
                  // Logo/Icon
                  Container(
                    width: 100,
                    height: 100,
                    decoration: BoxDecoration(
                      color: AppTheme.primaryGreen.withOpacity(0.1),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(
                      Icons.eco,
                      size: 60,
                      color: AppTheme.primaryGreen,
                    ),
                  ),
                  const SizedBox(height: 32),
                  // Title
                  Text(
                    _isOtpSent ? 'Enter OTP' : 'Welcome to Eco Earn',
                    textAlign: TextAlign.center,
                    style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                          color: AppTheme.primaryGreen,
                          fontWeight: FontWeight.bold,
                        ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    _isOtpSent
                        ? 'We sent a 6-digit code to\n${_phoneNumber.isNotEmpty ? _phoneNumber : _phoneController.text}'
                        : 'Enter your phone number to continue',
                    textAlign: TextAlign.center,
                    style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                          color: AppTheme.darkGray,
                        ),
                  ),
                  const SizedBox(height: 48),
                  // Phone Number Input (if OTP not sent)
                  if (!_isOtpSent) ...[
                    TextFormField(
                      controller: _phoneController,
                      keyboardType: TextInputType.phone,
                      decoration: InputDecoration(
                        labelText: 'Phone Number',
                        hintText: '+1 234 567 8900',
                        prefixIcon: const Icon(Icons.phone),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      validator: (value) {
                        if (value == null || value.trim().isEmpty) {
                          return 'Please enter your phone number';
                        }
                        if (value.trim().length < 10) {
                          return 'Please enter a valid phone number';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 24),
                    CustomButton(
                      text: 'Send OTP',
                      onPressed: _sendOtp,
                      isLoading: _isLoading,
                    ),
                  ],
                  // OTP Input (if OTP sent)
                  if (_isOtpSent) ...[
                    PinCodeTextField(
                      appContext: context,
                      length: 6,
                      controller: _otpController,
                      keyboardType: TextInputType.number,
                      pinTheme: PinTheme(
                        shape: PinCodeFieldShape.box,
                        borderRadius: BorderRadius.circular(12),
                        fieldHeight: 60,
                        fieldWidth: 50,
                        activeFillColor: Colors.white,
                        inactiveFillColor: AppTheme.lightGray,
                        selectedFillColor: Colors.white,
                        activeColor: AppTheme.primaryGreen,
                        inactiveColor: AppTheme.mediumGray,
                        selectedColor: AppTheme.primaryGreen,
                      ),
                      enableActiveFill: true,
                      onCompleted: (value) {
                        _verifyOtp();
                      },
                    ),
                    const SizedBox(height: 24),
                    CustomButton(
                      text: 'Verify OTP',
                      onPressed: _verifyOtp,
                      isLoading: _isLoading,
                    ),
                    const SizedBox(height: 16),
                    if (!_canResend)
                      Text(
                        'Resend code in ${_countdown}s',
                        textAlign: TextAlign.center,
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                              color: AppTheme.darkGray,
                            ),
                      )
                    else
                      TextButton(
                        onPressed: _resendOtp,
                        child: const Text('Resend OTP'),
                      ),
                    const SizedBox(height: 16),
                    TextButton(
                      onPressed: () {
                        if (!mounted) return;
                        setState(() {
                          _isOtpSent = false;
                          _otpController.clear();
                          _phoneNumber = '';
                          _countdown = 0;
                          _canResend = false;
                        });
                      },
                      child: const Text('Change Phone Number'),
                    ),
                  ],
                  const SizedBox(height: 32),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

