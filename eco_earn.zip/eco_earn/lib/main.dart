import 'package:eco_earn/firebase_options.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
// import 'package:firebase_core/firebase_core.dart'; // Uncomment when Firebase is configured
import 'theme/app_theme.dart';
import 'screens/auth/phone_login_screen.dart';
import 'screens/main/main_screen.dart';
import 'screens/onboarding/onboarding_screen.dart';
import 'providers/auth_provider.dart';
import 'services/notification_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Initialize Firebase (you'll need to add firebase_options.dart)
  // Uncomment when Firebase is configured:
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  
  // Initialize notifications
  await NotificationService().initialize();
  
  runApp(
    const ProviderScope(
      child: EcoEarnApp(),
    ),
  );
}

class EcoEarnApp extends ConsumerWidget {
  const EcoEarnApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(authProvider);

    return MaterialApp(
      title: 'Eco Earn',
      theme: AppTheme.lightTheme,
      debugShowCheckedModeBanner: false,
      home: user == null
          ? const PhoneLoginScreen()
          : user.hasOnboarded
              ? const MainScreen()
              : const OnboardingScreen(),
    );
  }
}
