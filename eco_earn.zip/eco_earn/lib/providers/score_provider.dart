import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../services/storage_service.dart';
import '../models/task_model.dart';
import 'tasks_provider.dart';

final monthlyScoreProvider = StateNotifierProvider<MonthlyScoreNotifier, int>((ref) {
  return MonthlyScoreNotifier(ref);
});

final monthlyBonusProvider = StateNotifierProvider<MonthlyBonusNotifier, double>((ref) {
  return MonthlyBonusNotifier();
});

class MonthlyScoreNotifier extends StateNotifier<int> {
  final Ref _ref;
  final StorageService _storageService = StorageService();

  MonthlyScoreNotifier(this._ref) : super(0) {
    _loadScore();
    _calculateScoreFromTasks();
    watchTasks(); // Watch for task changes
  }

  Future<void> _loadScore() async {
    final score = await _storageService.getMonthlyScore();
    state = score;
  }

  // Calculate score from tasks where isVerified is true
  void _calculateScoreFromTasks() {
    final tasksAsync = _ref.read(tasksProvider);
    tasksAsync.whenData((tasks) {
      final verifiedTasks = tasks.where((task) => task.isVerified).toList();
      final totalPoints = verifiedTasks.fold<int>(0, (sum, task) => sum + task.points);
      
      print('📊 Recalculating score from tasks: $totalPoints points from ${verifiedTasks.length} verified tasks (isVerified: true)');
      
      state = totalPoints.clamp(0, 1000);
      _storageService.saveMonthlyScore(state);
      
      // Update bonus automatically
      final bonusNotifier = _ref.read(monthlyBonusProvider.notifier);
      bonusNotifier.updateBonus(state);
    });
  }
  
  // Watch tasks and recalculate score when tasks change
  void watchTasks() {
    _ref.listen<AsyncValue<List<EcoTask>>>(tasksProvider, (previous, next) {
      next.whenData((tasks) {
        _calculateScoreFromTasks();
      });
    });
  }

  // This method is kept for backward compatibility but score is now calculated from tasks
  Future<void> addPoints(int points) async {
    // Score is now calculated automatically from completed tasks
    // This method updates the score but will be overridden by task calculation
    state = (state + points).clamp(0, 1000);
    await _storageService.saveMonthlyScore(state);
    _calculateScoreFromTasks();
  }

  Future<void> setScore(int score) async {
    state = score.clamp(0, 1000);
    await _storageService.saveMonthlyScore(state);
  }

  Future<void> resetScore() async {
    state = 0;
    await _storageService.saveMonthlyScore(0);
  }

  // Recalculate score from tasks
  Future<void> recalculateFromTasks() async {
    _calculateScoreFromTasks();
  }
}

class MonthlyBonusNotifier extends StateNotifier<double> {
  final StorageService _storageService = StorageService();

  MonthlyBonusNotifier() : super(0.0) {
    _loadBonus();
  }

  Future<void> _loadBonus() async {
    final bonus = await _storageService.getMonthlyBonus();
    state = bonus;
  }

  Future<void> updateBonus(int monthlyScore) async {
    // Calculate bonus: €1 per 50 points, max €20
    final bonus = (monthlyScore / 50 * 1.0).clamp(0.0, 20.0);
    state = bonus;
    await _storageService.saveMonthlyBonus(bonus);
  }

  Future<void> setBonus(double bonus) async {
    state = bonus;
    await _storageService.saveMonthlyBonus(bonus);
  }
}

// Combined provider that updates bonus when score changes
final scoreBonusSyncProvider = Provider<void>((ref) {
  final score = ref.watch(monthlyScoreProvider);
  final bonusNotifier = ref.read(monthlyBonusProvider.notifier);
  
  Future.microtask(() {
    bonusNotifier.updateBonus(score);
  });
});

