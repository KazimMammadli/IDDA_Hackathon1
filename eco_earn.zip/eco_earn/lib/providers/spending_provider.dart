import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/spending_model.dart';
import '../services/mock_data_service.dart';

final spendingCategoriesProvider = Provider<List<SpendingCategory>>((ref) {
  return MockDataService.getSpendingCategories();
});

