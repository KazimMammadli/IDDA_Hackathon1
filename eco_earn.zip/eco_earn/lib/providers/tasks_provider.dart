import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/task_model.dart';
import '../services/storage_service.dart';
import '../services/api_service.dart';
import '../services/mock_data_service.dart';
import 'auth_provider.dart';

final tasksProvider = StateNotifierProvider<TasksNotifier, AsyncValue<List<EcoTask>>>((ref) {
  return TasksNotifier(ref.read(apiServiceProvider));
});

class TasksNotifier extends StateNotifier<AsyncValue<List<EcoTask>>> {
  final ApiService _apiService;
  final StorageService _storageService = StorageService();

  TasksNotifier(this._apiService) : super(const AsyncValue.loading()) {
    loadTasks();
  }

  Future<void> loadTasks() async {
    try {
      // Try to get user first
      final user = await _storageService.getUser();
      
      if (user == null) {
        // No user, use mock data
        final tasks = MockDataService.generateDailyTasks();
        state = AsyncValue.data(tasks);
        return;
      }

      // Try to fetch from API using getUserTasks endpoint
      try {
        final response = await _apiService.getUserTasks(user.id);
        
        if (response.statusCode == 200) {
          // Handle different response formats
          List<dynamic> data;
          if (response.data is List) {
            data = response.data;
          } else if (response.data is Map) {
            data = response.data['tasks'] ?? 
                   response.data['data'] ?? 
                   (response.data['items'] is List ? response.data['items'] : []);
          } else {
            data = [];
          }
          
          final tasks = data
              .map((json) {
                try {
                  return EcoTask.fromJson(json as Map<String, dynamic>);
                } catch (e) {
                  print('Error parsing task: $e, JSON: $json');
                  return null;
                }
              })
              .whereType<EcoTask>()
              .toList();
          
          // Save to local storage
          await _storageService.saveTasks(tasks);
          state = AsyncValue.data(tasks);
          
          // Calculate points from completed tasks (where isVerified is true)
          final completedTasks = tasks.where((task) => task.isVerified).toList();
          final totalPoints = completedTasks.fold<int>(0, (sum, task) => sum + task.points);
          print('📊 Calculated total points from verified tasks: $totalPoints (${completedTasks.length} verified tasks)');
          
          return;
        }
      } catch (e) {
        print('Error fetching tasks from API: $e');
        // Fall through to use cached or mock data
      }

      // Fallback: Load from local storage
      final savedTasks = await _storageService.getTasks();
      if (savedTasks.isNotEmpty) {
        state = AsyncValue.data(savedTasks);
        return;
      }

      // Last resort: Use mock data
      final tasks = MockDataService.generateDailyTasks();
      await _storageService.saveTasks(tasks);
      state = AsyncValue.data(tasks);
    } catch (e, stackTrace) {
      state = AsyncValue.error(e, stackTrace);
    }
  }

  // Tasks are completed in the background based on completedAt field
  // Users cannot manually complete tasks
  // This method is kept for backward compatibility but does nothing
  Future<void> completeTask(String taskId) async {
    // Tasks are now calculated in the background via API
    // This method is a no-op as tasks can't be manually completed
    print('Task completion is handled in the background. completedAt must come from API.');
  }

  Future<void> refreshTasks() async {
    await loadTasks();
  }

  // Calculate points from tasks where isVerified is true
  int get totalPoints {
    final currentState = state;
    if (!currentState.hasValue) return 0;
    
    return currentState.value!
        .where((task) => task.isVerified)
        .fold<int>(0, (sum, task) => sum + task.points);
  }

  int get completedCount {
    final currentState = state;
    if (!currentState.hasValue) return 0;
    
    return currentState.value!.where((task) => task.isVerified).length;
  }
}
