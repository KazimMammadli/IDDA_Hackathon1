import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/user_model.dart';
import '../services/storage_service.dart';
import '../services/api_service.dart';

final apiServiceProvider = Provider<ApiService>((ref) => ApiService());

final authProvider = StateNotifierProvider<AuthNotifier, User?>((ref) {
  return AuthNotifier(ref.read(apiServiceProvider));
});

class AuthNotifier extends StateNotifier<User?> {
  final ApiService _apiService;
  final StorageService _storageService = StorageService();

  AuthNotifier(this._apiService) : super(null) {
    _loadUser();
  }

  Future<void> _loadUser() async {
    final user = await _storageService.getUser();
    if (user != null) {
      state = user;
      _apiService.setAuthToken(user.authToken ?? '');
      _apiService.setUserId(user.id);
      
      // Refresh user info from API to get latest bank connection status
      // Use a microtask to avoid blocking initialization
      Future.microtask(() async {
        await refreshUserInfo();
      });
    }
  }

  Future<bool> sendOtp(String phoneNumber) async {
    // Mock OTP sending - simulate network delay
    await Future.delayed(const Duration(seconds: 1));
    
    // For demo: Always succeed if phone number is valid
    if (phoneNumber.trim().length >= 10) {
      print('Mock: OTP sent to $phoneNumber (use 123456 to verify)');
      return true;
    }
    return false;
  }

  Future<Map<String, dynamic>?> verifyOtp(String phoneNumber, String otp) async {
    // Mock OTP verification - simulate network delay
    await Future.delayed(const Duration(seconds: 1));
    
    // For demo: Accept any 6-digit OTP
    if (otp.length != 6) {
      throw Exception('OTP must be 6 digits');
    }
    
    print('Mock: Verifying OTP $otp for $phoneNumber');
    
    // Check if user already exists in local storage
    final existingUser = await _storageService.getUser();
    final needsRegistration = existingUser == null || existingUser.phone != phoneNumber;
    
    // Generate mock token and user ID
    final mockToken = 'mock_token_${DateTime.now().millisecondsSinceEpoch}';
    final mockUserId = existingUser?.id ?? DateTime.now().millisecondsSinceEpoch.toString();
    
    if (!needsRegistration && existingUser != null) {
      // User exists, restore their session
      final token = existingUser.authToken ?? mockToken;
      _apiService.setAuthToken(token);
      _apiService.setUserId(existingUser.id);
      state = existingUser;
      
      // Refresh user info from API to get latest bank connection status
      Future.microtask(() async {
        await refreshUserInfo();
      });
      
      return {
        'authToken': token,
        'needsRegistration': false,
        'userId': existingUser.id,
      };
    }
    
    // New user or different phone number - needs registration
    return {
      'authToken': mockToken,
      'needsRegistration': true,
      'userId': mockUserId,
    };
  }

  Future<bool> registerUser({
    required String phone,
    required String name,
    required String surname,
    String? authToken,
  }) async {
    try {
      // Generate user ID
      final userId = 'usr_${DateTime.now().millisecondsSinceEpoch}';
      final mockToken = authToken ?? 'mock_token_$userId';
      
      print('Registering user $name $surname with phone $phone');
      
      // Send registration data to API
      try {
        final response = await _apiService.registerUser(
          userId: userId,
          phone: phone,
          name: name,
          surname: surname,
          bankConnected: false, // Default to false
        );
        
        print('Registration API response: ${response.statusCode}');
        // API call succeeded (or webhook was sent)
      } catch (e) {
        print('Error calling registration API: $e');
        // Continue anyway - user is still registered locally
      }
      
      // Create user object
      final user = User(
        id: userId,
        phone: phone,
        name: name,
        surname: surname,
        authToken: mockToken,
        hasOnboarded: true,
        hasBankConnected: false, // Default to false
        createdAt: DateTime.now(),
      );

      // Save to local storage
      await _storageService.saveUser(user);
      _apiService.setAuthToken(mockToken);
      _apiService.setUserId(userId);
      state = user;

      return true;
    } catch (e) {
      print('Error registering user: $e');
      return false;
    }
  }

  Future<void> refreshUserInfo() async {
    if (state == null) return;

    try {
      final currentUser = state!;
      
      // Fetch updated user info from API
      try {
        final response = await _apiService.getUserInfo(currentUser.id);
        
        if (response.statusCode == 200) {
          // Parse user data from API response
          final Map<String, dynamic> userData;
          if (response.data is Map) {
            userData = response.data;
          } else {
            print('Unexpected API response format: ${response.data}');
            // Fallback to local storage
            final user = await _storageService.getUser();
            if (user != null && user.id == currentUser.id) {
              state = user;
            }
            return;
          }

          // Create updated user from API data
          final updatedUser = User.fromJson(userData);
          
          // Preserve auth token from current user if not in API response
          final finalUser = updatedUser.copyWith(
            authToken: updatedUser.authToken ?? currentUser.authToken,
            id: updatedUser.id.isNotEmpty ? updatedUser.id : currentUser.id,
          );
          
          // Save to local storage and update state
          await _storageService.saveUser(finalUser);
          state = finalUser;
          
          print('✅ User info refreshed from API. Bank connected: ${finalUser.hasBankConnected}');
          return;
        }
      } catch (e) {
        print('⚠️ Error fetching user info from API: $e');
        // Fallback to local storage
      }

      // Fallback: Reload from local storage
      final user = await _storageService.getUser();
      if (user != null && user.id == currentUser.id) {
        state = user;
      }
    } catch (e) {
      print('Error refreshing user info: $e');
      // Continue with existing user data
    }
  }

  Future<void> completeOnboarding() async {
    if (state != null) {
      final updatedUser = state!.copyWith(hasOnboarded: true);
      await _storageService.saveUser(updatedUser);
      state = updatedUser;
    }
  }

  Future<bool> connectBank({
    required String cardNumber,
    required String expiryDate,
    required String cvv,
    required String cardholderName,
  }) async {
    if (state == null) return false;

    try {
      final user = state!;
      
      // Send bank connection update to API
      try {
        final response = await _apiService.updateBankConnection(
          userId: user.id,
          phone: user.phone ?? '',
          name: user.fullName,
          email: user.email,
          registeredAt: user.createdAt ?? DateTime.now(),
          avatar: null, // Will use default
        );
        
        print('Bank connection API response: ${response.statusCode}');
      } catch (e) {
        print('Error calling bank connection API: $e');
        // Continue anyway - update locally
      }
      
      // Refresh user info from API to get latest bank connection status
      await refreshUserInfo();
      
      // If refresh didn't update (e.g., API error), update locally as fallback
      if (state?.hasBankConnected != true) {
        final updatedUser = user.copyWith(hasBankConnected: true);
        await _storageService.saveUser(updatedUser);
        state = updatedUser;
      }
      
      return true;
    } catch (e) {
      print('Error connecting bank: $e');
      return false;
    }
  }

  Future<void> logout() async {
    await _storageService.clearUser();
    _apiService.clearAuth();
    state = null;
  }

  Future<void> updateUser(User user) async {
    await _storageService.saveUser(user);
    state = user;
    
    // Mock: Just save locally
    // In real app, this would sync with backend
    print('Mock: User updated locally');
  }
}
