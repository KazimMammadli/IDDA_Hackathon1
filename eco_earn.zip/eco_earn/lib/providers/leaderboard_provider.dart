import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/leaderboard_model.dart';
import '../services/mock_data_service.dart';
import 'auth_provider.dart';

final leaderboardProvider = Provider<List<LeaderboardEntry>>((ref) {
  final currentUser = ref.watch(authProvider);
  final userId = currentUser?.id ?? '';
  return MockDataService.generateLeaderboard(userId);
});

final userRankProvider = Provider<int?>((ref) {
  final currentUser = ref.watch(authProvider);
  final leaderboard = ref.watch(leaderboardProvider);
  
  if (currentUser == null) return null;
  
  // Find rank based on score (simplified - in real app would use actual score)
  int rank = 25; // Default middle rank
  for (var entry in leaderboard) {
    if (entry.userId == currentUser.id) {
      rank = entry.rank;
      break;
    }
  }
  
  return rank;
});

