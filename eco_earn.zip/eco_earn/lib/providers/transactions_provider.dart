import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/transaction_model.dart';
import '../services/api_service.dart';
import 'auth_provider.dart';

final transactionsProvider =
    StateNotifierProvider<TransactionsNotifier, AsyncValue<List<Transaction>>>((ref) {
  return TransactionsNotifier(ref.read(apiServiceProvider));
});

class TransactionsNotifier extends StateNotifier<AsyncValue<List<Transaction>>> {
  final ApiService _apiService;

  TransactionsNotifier(this._apiService) : super(const AsyncValue.loading());

  Future<void> loadTransactions(String userId) async {
    state = const AsyncValue.loading();

    try {
      final response = await _apiService.getUserTransactions(userId);

      if (response.statusCode == 200) {
        // Handle response: can be a list directly or wrapped in an object
        final List<dynamic> data;
        if (response.data is List) {
          data = response.data;
        } else if (response.data is Map) {
          data = response.data['transactions'] ?? 
                 response.data['data'] ?? 
                 (response.data['items'] is List ? response.data['items'] : []);
        } else {
          data = [];
        }

        final transactions = data
            .map((json) {
              try {
                return Transaction.fromJson(json as Map<String, dynamic>);
              } catch (e) {
                print('Error parsing transaction: $e, JSON: $json');
                return null;
              }
            })
            .whereType<Transaction>()
            .toList();

        state = AsyncValue.data(transactions);
      } else {
        state = AsyncValue.error(
          Exception('Failed to load transactions: ${response.statusCode}'),
          StackTrace.current,
        );
      }
    } catch (e, stackTrace) {
      state = AsyncValue.error(e, stackTrace);
    }
  }

  Future<void> refreshTransactions(String userId) async {
    await loadTransactions(userId);
  }
}

