# API Setup Guide for Eco Earn App

## Overview
This app is now configured to work with backend APIs. You need to provide the actual API endpoints and configure the app accordingly.

## Configuration Steps

### 1. Update API Base URL
Edit `lib/config/app_config.dart` and update the `baseUrl`:

```dart
static const String baseUrl = 'https://your-actual-api-url.com/api';
```

### 2. API Endpoints Required

The app expects the following endpoints:

#### Authentication
- **POST** `/auth/login` - Send OTP to phone number
  - Request: `{ "phone": "+1234567890" }`
  - Response: `{ "success": true, "message": "OTP sent" }`

- **POST** `/auth/verify-otp` - Verify OTP code
  - Request: `{ "phone": "+1234567890", "otp": "123456" }`
  - Response: `{ "token": "auth_token", "userId": "user_id", "needsRegistration": false }`

- **POST** `/auth/register` - Register new user
  - Request: `{ "phone": "+1234567890", "name": "John", "surname": "Doe" }`
  - Response: `{ "id": "user_id", "token": "auth_token", ...user data }`

#### User
- **GET** `/user/{userId}` - Get user information
  - Response: User object with all fields

- **PUT** `/user/update/{userId}` - Update user information
  - Request: User object JSON

#### Tasks
- **GET** `/tasks/daily?userId={userId}` - Get daily tasks
  - Response: `{ "tasks": [...task objects] }` or array of tasks

- **GET** `/tasks/status/{taskId}?userId={userId}` - Get task status
  - Response: Task status object

- **POST** `/tasks/complete/{taskId}` - Mark task as complete
  - Request: `{ "userId": "user_id" }`
  - Response: Updated task object

### 3. Task JSON Format

Tasks should be returned in this format:

```json
{
  "id": "task_id",
  "title": "Use public transport today",
  "description": "Complete description of the task...",
  "category": "Transport",
  "points": 50,
  "iconUrl": "https://example.com/icon.png",
  "tips": ["Tip 1", "Tip 2"],
  "startDate": "2024-01-01T00:00:00Z",
  "endDate": "2024-01-01T23:59:59Z",
  "isCompleted": false,
  "completedAt": null,
  "progress": 0.5,
  "metadata": {}
}
```

### 4. Firebase Setup (Optional but Recommended)

For push notifications:

1. Add `firebase_options.dart` to your project
2. Uncomment Firebase initialization in `lib/main.dart`:
   ```dart
   await Firebase.initializeApp();
   ```
3. Configure Firebase Cloud Messaging in Firebase Console
4. Update notification topics/subscriptions as needed

### 5. Background Task Processing

The app expects tasks to be calculated in the background by:
- Monitoring bank API connections
- Analyzing spending patterns
- Automatically completing tasks when criteria are met
- Sending notifications when tasks are auto-completed

You'll need to implement this backend logic separately.

### 6. Testing with Mock Data

Currently, the app falls back to mock data if:
- API calls fail
- No user is logged in
- Endpoints return errors

This allows you to develop and test the UI while setting up the backend.

## Current Status

✅ Phone + OTP authentication flow
✅ Registration with name/surname
✅ Task detail pages
✅ API service layer structure
✅ Notification service setup
✅ Task completion with score updates
✅ User ID storage and management

## Next Steps

1. Provide your actual API base URL
2. Implement backend endpoints matching the expected format
3. Test the authentication flow
4. Configure Firebase for notifications (optional)
5. Set up background task calculation logic
6. Test task completion and scoring

## Notes

- The app handles errors gracefully and falls back to local storage/mock data
- User data is stored locally and synced with the backend
- Tasks are fetched daily from the API
- Task completion is sent to the API and also stored locally
- All API calls include authentication tokens when available

